#!/usr/bin/env python3
"""Comprehensive test of all AlphaVox API endpoints"""

import requests
import time
import json

# Base URL for the Flask app
BASE_URL = "http://localhost:3000"

def test_endpoint(method, url, data=None, expected_status=200):
    """Test a single API endpoint"""
    try:
        if method.upper() == "GET":
            response = requests.get(url, timeout=5)
        elif method.upper() == "POST":
            response = requests.post(url, json=data, timeout=5)
        
        print(f"{method} {url}: Status {response.status_code}", end="")
        
        if response.status_code == expected_status:
            print(" ✓")
            if response.content:
                try:
                    json_data = response.json()
                    print(f"  Response: {json.dumps(json_data, indent=2)}")
                except:
                    print(f"  Response: {response.text[:200]}")
            return True
        else:
            print(" ✗")
            print(f"  Expected {expected_status}, got {response.status_code}")
            print(f"  Error: {response.text[:200]}")
            return False
            
    except requests.exceptions.ConnectionError:
        print(f"{method} {url}: Connection refused ✗")
        return False
    except requests.exceptions.Timeout:
        print(f"{method} {url}: Timeout ✗")
        return False
    except Exception as e:
        print(f"{method} {url}: Error - {e} ✗")
        return False

def main():
    print("Testing AlphaVox API Endpoints...")
    print("=" * 50)
    
    # Test basic endpoints first
    print("\n1. Testing Basic Pages:")
    test_endpoint("GET", f"{BASE_URL}/")
    test_endpoint("GET", f"{BASE_URL}/learning")
    
    print("\n2. Testing Learning Hub Endpoints:")
    test_endpoint("GET", f"{BASE_URL}/learning/analytics")
    test_endpoint("GET", f"{BASE_URL}/learning/sessions")  
    test_endpoint("GET", f"{BASE_URL}/learning/milestones")
    
    print("\n3. Testing Behavior Capture Endpoints:")
    test_endpoint("GET", f"{BASE_URL}/api/behavior/status")
    test_endpoint("POST", f"{BASE_URL}/api/behavior/start")
    test_endpoint("GET", f"{BASE_URL}/api/behavior/status")  # Should show active now
    test_endpoint("POST", f"{BASE_URL}/api/behavior/stop")
    test_endpoint("GET", f"{BASE_URL}/api/behavior/status")  # Should show inactive now
    
    print("\n4. Testing Caregiver Endpoints:")
    test_endpoint("GET", f"{BASE_URL}/caregiver", expected_status=302)  # Redirect to login
    
    print("\n5. Testing Admin/API Endpoints:")
    test_endpoint("GET", f"{BASE_URL}/api/conversation")
    test_endpoint("GET", f"{BASE_URL}/api/status")
    
    print("\nTesting complete!")

if __name__ == "__main__":
    main()