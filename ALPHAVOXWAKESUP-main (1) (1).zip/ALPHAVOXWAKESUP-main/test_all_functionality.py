#!/usr/bin/env python3
"""
Test all AlphaVox functionality to see what actually works
"""

import requests
import json
import time

BASE_URL = "http://localhost:3000"
session = requests.Session()

def test_login():
    """Test login functionality"""
    print("🔐 Testing Login...")
    
    # First get the main page
    response = session.get(f"{BASE_URL}/")
    if response.status_code != 200:
        print("❌ Main page not accessible")
        return False
    
    # Submit login form
    login_data = {"name": "TestUser"}
    response = session.post(f"{BASE_URL}/start", data=login_data)
    
    if response.status_code == 200:
        print("✅ Login successful")
        return True
    else:
        print(f"❌ Login failed: {response.status_code}")
        return False

def test_behavior_capture_api():
    """Test behavior capture API endpoints"""
    print("\n🎥 Testing Behavior Capture API...")
    
    # Test start behavior capture
    print("  Testing /api/behavior/start...")
    response = session.post(f"{BASE_URL}/api/behavior/start")
    print(f"    Status: {response.status_code}")
    if response.status_code == 200:
        try:
            data = response.json()
            print(f"    Response: {data}")
        except:
            print(f"    Response: {response.text[:100]}")
    
    # Test behavior status
    print("  Testing /api/behavior/status...")
    response = session.get(f"{BASE_URL}/api/behavior/status")
    print(f"    Status: {response.status_code}")
    if response.status_code == 200:
        try:
            data = response.json()
            print(f"    Response: {data}")
        except:
            print(f"    Response: {response.text[:100]}")
    
    # Test behavior observations
    print("  Testing /api/behavior/observations...")
    response = session.get(f"{BASE_URL}/api/behavior/observations")
    print(f"    Status: {response.status_code}")
    if response.status_code == 200:
        try:
            data = response.json()
            print(f"    Response: {data}")
        except:
            print(f"    Response: {response.text[:100]}")
    
    # Test stop behavior capture
    print("  Testing /api/behavior/stop...")
    response = session.post(f"{BASE_URL}/api/behavior/stop")
    print(f"    Status: {response.status_code}")
    if response.status_code == 200:
        try:
            data = response.json()
            print(f"    Response: {data}")
        except:
            print(f"    Response: {response.text[:100]}")

def test_learning_hub_api():
    """Test learning hub functionality"""
    print("\n📚 Testing Learning Hub...")
    
    # Test learning sessions API
    print("  Testing /learning/start_session...")
    session_data = {
        "focus_areas": ["communication"],
        "duration": 30,
        "difficulty": "intermediate"
    }
    response = session.post(f"{BASE_URL}/learning/start_session", 
                          json=session_data,
                          headers={"Content-Type": "application/json"})
    print(f"    Status: {response.status_code}")
    if response.status_code == 200:
        try:
            data = response.json()
            print(f"    Response: {data}")
        except:
            print(f"    Response: {response.text[:100]}")

def test_caregiver_portal_api():
    """Test caregiver portal functionality"""
    print("\n👥 Testing Caregiver Portal...")
    
    # Test caregiver analytics
    print("  Testing /caregiver/analytics...")
    response = session.get(f"{BASE_URL}/caregiver/analytics")
    print(f"    Status: {response.status_code}")
    
    # Test add caregiver note
    print("  Testing /caregiver/add-note...")
    note_data = {
        "note": "Test observation note",
        "category": "observation",
        "tags": "test,behavior"
    }
    response = session.post(f"{BASE_URL}/caregiver/add-note", data=note_data)
    print(f"    Status: {response.status_code}")
    if response.status_code == 200:
        try:
            data = response.json()
            print(f"    Response: {data}")
        except:
            print(f"    Response: {response.text[:100]}")

def test_page_access():
    """Test access to main pages"""
    print("\n🌐 Testing Page Access...")
    
    pages = [
        "/learning/",
        "/learning/analytics", 
        "/learning/sessions",
        "/learning/milestones",
        "/caregiver",
        "/behavior"
    ]
    
    for page in pages:
        response = session.get(f"{BASE_URL}{page}")
        status = "✅" if response.status_code == 200 else "❌"
        print(f"    {page}: {status} {response.status_code}")

def main():
    print("🚀 AlphaVox Functionality Test")
    print("=" * 50)
    
    # Test login first
    if not test_login():
        print("❌ Cannot proceed without login")
        return
    
    # Test all functionality
    test_page_access()
    test_behavior_capture_api()
    test_learning_hub_api()
    test_caregiver_portal_api()
    
    print("\n" + "=" * 50)
    print("🏁 Test Complete!")

if __name__ == "__main__":
    main()