#!/usr/bin/env python3
"""Test AlphaVox endpoints using built-in urllib"""

import urllib.request
import urllib.error
import json
import time

def test_url(url, method="GET", data=None):
    """Test a URL and return status"""
    try:
        if method == "POST" and data:
            data = json.dumps(data).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
        else:
            req = urllib.request.Request(url)
        
        with urllib.request.urlopen(req, timeout=5) as response:
            status = response.getcode()
            body = response.read().decode('utf-8')
            print(f"{method} {url}: {status} ✓")
            if body and len(body) < 300:
                print(f"  Response: {body}")
            elif body:
                print(f"  Response: {body[:100]}...")
            return True
            
    except urllib.error.HTTPError as e:
        print(f"{method} {url}: {e.code} - {e.reason}")
        try:
            error_body = e.read().decode('utf-8')
            if error_body:
                print(f"  Error: {error_body[:200]}")
        except:
            pass
        return False
    except urllib.error.URLError as e:
        print(f"{method} {url}: Connection error - {e.reason}")
        return False
    except Exception as e:
        print(f"{method} {url}: {e}")
        return False

def main():
    base_url = "http://localhost:3000"
    
    print("Testing AlphaVox API endpoints...")
    print("=" * 50)
    
    # Test server is running
    print("\n1. Testing server connectivity:")
    if not test_url(f"{base_url}/"):
        print("❌ Server not responding - make sure Flask app is running on port 3000")
        return
    
    print("\n2. Testing Learning Hub pages:")
    test_url(f"{base_url}/learning/analytics")
    test_url(f"{base_url}/learning/sessions")
    test_url(f"{base_url}/learning/milestones")
    
    print("\n3. Testing Behavior Capture API:")
    test_url(f"{base_url}/api/behavior/status")
    test_url(f"{base_url}/api/behavior/start", "POST")
    test_url(f"{base_url}/api/behavior/status")
    test_url(f"{base_url}/api/behavior/stop", "POST") 
    
    print("\n4. Testing other API endpoints:")
    test_url(f"{base_url}/api/status")
    
    print("\nTest complete!")

if __name__ == "__main__":
    main()