#!/usr/bin/env python3
"""Test behavior capture initialization"""

try:
    from behavior_capture import get_behavior_capture
    print("Importing get_behavior_capture... OK")
    
    behavior_capture = get_behavior_capture()
    print(f"Creating behavior_capture instance... OK - Type: {type(behavior_capture)}")
    
    # Check if it has the required methods
    if hasattr(behavior_capture, 'start_tracking'):
        print("Has start_tracking method... OK")
    else:
        print("Missing start_tracking method... FAIL")
        
    if hasattr(behavior_capture, 'stop_tracking'):
        print("Has stop_tracking method... OK")
    else:
        print("Missing stop_tracking method... FAIL")
        
    if hasattr(behavior_capture, 'is_tracking'):
        print(f"Has is_tracking attribute... OK - Current value: {behavior_capture.is_tracking}")
    else:
        print("Missing is_tracking attribute... FAIL")

except ImportError as e:
    print(f"Import error: {e}")
except Exception as e:
    print(f"Other error: {e}")