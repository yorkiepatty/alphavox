#!/usr/bin/env python3
"""Minimal test to check what's breaking the Flask app startup"""

import os
import sys

# Set up the environment
os.chdir('/Users/EverettN/ALPHAVOXWAKESUP')

print("Testing Flask app startup...")

try:
    print("1. Testing imports...")
    import app
    print("   ✓ App module imports successfully")
    
    print("2. Testing Flask app object...")
    flask_app = getattr(app, 'app', None)
    if flask_app:
        print("   ✓ Flask app object exists")
        print(f"   ✓ App name: {flask_app.name}")
    else:
        print("   ✗ No Flask app object found")
        
    print("3. Testing routes...")
    with flask_app.app_context():
        routes = []
        for rule in flask_app.url_map.iter_rules():
            if 'learning' in rule.rule:
                routes.append(f"{rule.rule} -> {rule.endpoint}")
        
        if routes:
            print("   ✓ Learning routes found:")
            for route in routes:
                print(f"     {route}")
        else:
            print("   ✗ No learning routes found")
            
    print("\n✓ All basic tests passed - Flask app should be able to start")
    
except ImportError as e:
    print(f"✗ Import error: {e}")
except Exception as e:
    print(f"✗ Error: {e}")
    import traceback
    traceback.print_exc()